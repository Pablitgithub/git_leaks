module.exports = {
  lowercase: str => str.toLowerCase(),
};
